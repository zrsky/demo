const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isClick: true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },
  /**
   * 立即入驻
   */
  commit() {
    const _this = this;
    if (_this.data.isClick) {
      _this.setData({
        isClick: false
      })
      const para = {
        unionId: app.globalData.userInfo.unionId,
        token: app.globalData.token
      };
      app.postRequest(app.globalData.api.queryByCondition, para).then((res) => {
        if (res.data.code == '200' && res.data.success) {
          if (res.data.data != null) {
            const approveStatus = res.data.data.approveStatus;
            wx.navigateTo({
              url: `../auditStatus/auditStatus?approveStatus=${approveStatus}`,
            })
          } else {
            wx.navigateTo({
              url: '../verification/verification',
            })
          }
          _this.setData({
            isClick: true
          })
        } else {
          wx.showToast({
            title: res.data.message,
            icon: 'none',
            duration: 1000,
            mask: true
          });
        }
      })
    }
  }
})