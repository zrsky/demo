const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    realName: '',
    cardNum: '',
    showImgOne: false,
    chooseImgOne: true,
    imgOneUrl: '',
    showImgTwo: false,
    chooseImgTwo: true,
    imgTwoUrl: '',
    showThree: false,
    chooseImgThree: true,
    imgThreeUrl: '',
    allUrl: [],
    loadingOne: false,
    loadingTwo: false,
    loadingThree: false,
    showModal: false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const editInfo = JSON.parse(options.editInfo);
    const _this = this;
    _this.setData({
      realName: editInfo.realName,
      cardNum: editInfo.cardNum,
      imgOneUrl: editInfo.cardFrontId,
      imgTwoUrl: editInfo.cardOppId,
      imgThreeUrl: editInfo.cardHandId,
      phone: editInfo.phone,
      userDistrictCode: editInfo.userDistrictCode
    })
    if (_this.data.imgOneUrl != '' ) {
      _this.setData({
        loadingOne: false,
        showImgOne: true,
        chooseImgOne: false
      })
    };
    if (_this.data.imgTwoUrl != '') {
      _this.setData({
        loadingTwo: false,
        showImgTwo: true,
        chooseImgTwo: false
      })
    };
    if (_this.data.imgThreeUrl != '') {
      _this.setData({
        loadingThree: false,
        showImgThree: true,
        chooseImgThree: false
      })
    }
    console.log(_this.data.imgOneUrl);
  },
  
  /**
   * 获取名字
   */
  getName(e) {
    const _this = this;
    const nameReg = /^[\u4e00-\u9fa5]{0,}$/;
    const name = e.detail.value;
    if (name != '') {
      if (nameReg.test(name)) {
        _this.setData({
          realName: name
        })
      } else {
        wx.showToast({
          title: '请输入中文',
          icon: 'none',
          duration: 1000,
          mask: true
        })
      }
    } else {
      wx.showToast({
        title: '请填写真实姓名',
        icon: 'none',
        duration: 1000,
        mask: true
      })
    }
  },
  /**
  * 获取身份证
  */
  getIdentity(e) {
    const _this = this;
    const IdcardExg = /^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X|x)$/;
    const identity = e.detail.value
    if (identity != '') {
      if (IdcardExg.test(identity)) {
        _this.setData({
          cardNum: identity
        })
      } else {
        wx.showToast({
          title: '身份证号格式错误',
          icon: 'none',
          duration: 1000,
          mask: true
        })
      }
    } else {
      wx.showToast({
        title: '请填写身份证号',
        icon: 'none',
        duration: 1000,
        mask: true
      })
    }
  },
  /**
  * 上传第一张图
  */
  chooseOneImg() {
    const _this = this;
    const imgOneUrl = _this.data.imgOneUrl;
    const allUrl = _this.data.allUrl;
    _this.setData({
      loadingOne: true
    });
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        // _this.setData({
        //   imgOneUrl: res.tempFilePaths[0],
        //   showImgOne: true,
        //   chooseImgOne: false
        // })
        // console.log(res.tempFilePaths[0])
        var tempFilePaths = res.tempFilePaths;
        tempFilePaths.forEach((item) => {
          wx.uploadFile({
            // url: 'https://dev.51ganjie.cn/supplyDemand/uploadpic.do', //仅为示例，非真实的接口地址
            url: app.globalData.url + app.globalData.api.uploadPic, //仅为示例，非真实的接口地址
            filePath: item,
            name: 'fileItem',
            header: {
              'content-type': 'multipart/form-data'
            },
            formData: {
              'user': 'test'
            },
            success: function (res) {
              var data = JSON.parse(res.data).data;
              // console.log(data);
              _this.setData({
                loadingOne: false,
                imgOneUrl: data.attachmentUrl,
                showImgOne: true,
                chooseImgOne: false
              })
            },
            complete: function (res) {
              _this.setData({
                loadingOne: false
              })
            }
          })
        })
      },
      complete: function (res) {
        _this.setData({
          loadingOne: false
        })
      }
    });
  },
  /**
  * 上传第二张图
  */
  chooseTwoImg() {
    const _this = this;
    const imgTwoUrl = _this.data.imgTwoUrl;
    _this.setData({
      loadingTwo: true
    });
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        // _this.setData({
        //   imgOneUrl: res.tempFilePaths[0],
        //   showImgOne: true,
        //   chooseImgOne: false
        // })
        // console.log(res.tempFilePaths[0])
        var tempFilePaths = res.tempFilePaths;
        tempFilePaths.forEach((item) => {
          wx.uploadFile({
            // url: 'https://dev.51ganjie.cn/supplyDemand/uploadpic.do', //仅为示例，非真实的接口地址
            url: app.globalData.url + app.globalData.api.uploadPic, //仅为示例，非真实的接口地址
            filePath: item,
            name: 'fileItem',
            header: {
              'content-type': 'multipart/form-data'
            },
            formData: {
              'user': 'test'
            },
            success: function (res) {
              var data = JSON.parse(res.data).data;
              // console.log(data);
              _this.setData({
                loadingTwo: false,
                imgTwoUrl: data.attachmentUrl,
                showImgTwo: true,
                chooseImgTwo: false,
              })
            }
          })
        })
      }
    });
  },
  /**
  * 上传第三张图
  */
  chooseThreeImg() {
    const _this = this;
    const imgThreeUrl = _this.data.imgThreeUrl;
    _this.setData({
      loadingThree: true
    });
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        // _this.setData({
        //   imgOneUrl: res.tempFilePaths[0],
        //   showImgOne: true,
        //   chooseImgOne: false
        // })
        // console.log(res.tempFilePaths[0])
        var tempFilePaths = res.tempFilePaths;
        tempFilePaths.forEach((item) => {
          wx.uploadFile({
            // url: 'https://dev.51ganjie.cn/supplyDemand/uploadpic.do', //仅为示例，非真实的接口地址
            url: app.globalData.url + app.globalData.api.uploadPic,
            filePath: item,
            name: 'fileItem',
            header: {
              'content-type': 'multipart/form-data'
            },
            formData: {
              'user': 'test'
            },
            success: function (res) {
              var data = JSON.parse(res.data).data;
              _this.setData({
                loadingThree: false,
                imgThreeUrl: data.attachmentUrl,
                showImgThree: true,
                chooseImgThree: false,
              })
            }
          })
        })
      }
    });
  },
  delOne() {
    this.setData({
      imgOneUrl: '',
      showImgOne: false,
      chooseImgOne: true,
      allUrl: []
    })
    // console.log(this.data.imgOneUrl);
  },
  delTwo() {
    this.setData({
      imgTwoUrl: '',
      showImgTwo: false,
      chooseImgTwo: true,
      allUrl: []
    })
  },
  delThree() {
    this.setData({
      imgThreeUrl: '',
      showImgThree: false,
      chooseImgThree: true,
      allUrl: []
    })
  },
  /**
  * 查看商家协议
  */
  agreement() {
    wx.navigateTo({
      url: '../agreement/agreement',
    })
  },
  /**
  * 提交认证
  */
  commit() {
    const _this = this;
    const approveStatus = 1;
    if (_this.data.realName == '' ) {
      wx.showToast({
        title: '请填写真实姓名',
        icon: 'none',
        duration: 1000,
        mask: true
      });
      return;
    };
    if (_this.data.cardNum == '') {
      wx.showToast({
        title: '请填写身份证号',
        icon: 'none',
        duration: 1000,
        mask: true
      });
      return;
    };
    if (_this.data.imgOneUrl == '') {
      wx.showToast({
        title: '请上传身份证正面',
        icon: 'none',
        duration: 1000,
        mask: true
      });
      return;
    };
    if (_this.data.imgTwoUrl == '') {
      wx.showToast({
        title: '请上传身份证背面',
        icon: 'none',
        duration: 1000,
        mask: true
      });
      return;
    };
    if (_this.data.imgThreeUrl == '') {
      wx.showToast({
        title: '请上传手持身份证照片',
        icon: 'none',
        duration: 1000,
        mask: true
      });
      return;
    }
    const para = {
      type: 1,
      realName: _this.data.realName,
      cardNum: _this.data.cardNum,
      cardFrontId: _this.data.imgOneUrl,
      cardOppId: _this.data.imgTwoUrl,
      cardHandId: _this.data.imgThreeUrl,
      userDistrictCode: _this.data.userDistrictCode,
      phone: _this.data.phone,
      token: app.globalData.token,
      unionId: app.globalData.userInfo.unionId
    };
    console.log(para);
    app.postRequest(app.globalData.api.insert, para).then((res) => {
      if (res.data.code == '200' && res.data.success) {
        wx.redirectTo({
          url: `../auditStatus/auditStatus?approveStatus=${approveStatus}`
        })
      } else {
        wx.showToast({
          title: res.data.message,
          icon: 'none',
          duration: 1000,
          mask: true
        })
      }
    })
  }
})