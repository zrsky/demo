const app = getApp();
// pages/goods/goodsList.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: '',
    // photo: '../../../img/common/head.png',
    name: '一棵小白菜',
    pendingPaymentCount: '',                // 待付款订单数
    pendingDeliveredCount: '',              // 待发货订单数
    deliveredCount: '',                     // 待收货订单数
    afterSaleCount: '',                      // 售后订单数
    tabBar: [],
    isClick: true
  },

  //初始化底部导航
  initTabBar() {
    let _this = this;
    let tabBar = app.globalData.tabBar, index = 1;
    if(tabBar.length == 3) {
      index = 2
    }
    for (let i = 0; i < tabBar.length; i++) {
      if (!tabBar[i].active && i == index) {
        let t = tabBar[i].iconPath;
        tabBar[i].iconPath = tabBar[i].selectedIconPath;
        tabBar[i].selectedIconPath = t;
        tabBar[i].active = true;

      } else if (tabBar[i].active && i != index) {
        let t = tabBar[i].iconPath;
        tabBar[i].iconPath = tabBar[i].selectedIconPath;
        tabBar[i].selectedIconPath = t;
        tabBar[i].active = false;
      }
    }
    this.setData({
      tabBar: tabBar
    })
  },

  jumgPages(e) {
    let tabBar = e.currentTarget.dataset.text;
    wx.redirectTo({
      url: tabBar.pagePath,
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // app.userInfoReadyCallback = res => {
    //   this.setData({
    //     userInfo: res.userInfo,
    //     hasUserInfo: true
    //   })
    // },
    this.initTabBar();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.init();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },
  /**
   * 初始化数据
   */
  init() {
    const _this = this;
    const para = {
      token: app.globalData.token
    }
    _this.setData({
      userInfo: app.globalData.userInfo
    })
    app.postRequest(app.globalData.api.queryMineShopCount,para).then( (res) =>{
      if(res.data.code == '200' && res.data.success) {
        _this.setData({
          pendingPaymentCount: res.data.data.pendingPaymentCount,
          pendingDeliveredCount: res.data.data.pendingDeliveredCount,
          deliveredCount: res.data.data.deliveredCount,
          afterSaleCount: res.data.data.afterSaleCount
        })
      }
    })
   
  },
  /**
   * 查看订单
   */
  handelOrder(e) {
    const id = e.currentTarget.dataset.id
     wx.navigateTo({
       url: `../myOrderList/myOrderList?id=${id}`,
     })
  },
  /**
   * 地址管理
   */
  addressManage() {
    wx.navigateTo({
      url: '../../../../../../goods/addressList/addressList?isCenter=isCenter',
    })
  },
  /**
   * 联系客服
   */
  callService() {
    wx.makePhoneCall({
      phoneNumber: '4000086600',
    })
  },
  /**
   * 商家入驻
   */
  merchant(e) {
    const _this = this;
    const para = {
      unionId: app.globalData.userInfo.unionId,
      token: app.globalData.token
    };
    if( _this.data.isClick ) {
      _this.setData({
        isClick: false
      })
      app.postRequest(app.globalData.api.queryByCondition, para).then((res) => {
        if (res.data.code == '200' && res.data.success) {
          if (res.data.data != null) {
            const approveStatus = res.data.data.approveStatus;
            if (approveStatus == 4 ) {
              wx.showToast({
                title: '您的商家账号已经被禁用',
                icon: 'none',
                duration: 1000,
                mask: true
              });
            }else {
              wx.navigateTo({
                url: `../auditStatus/auditStatus?approveStatus=${approveStatus}`,
              })
            }
          } else {
            wx.navigateTo({
              url: '../merchants/merchants',
            })
          }
          _this.setData({
            isClick: true
          })
        } else {
          wx.showToast({
            title: res.data.message,
            icon: 'none',
            duration: 1000,
            mask: true
          });
        }
      })
    }
  },
  /**
   * 设置
   */
  handelSetting() {
    wx.navigateTo({
      url: '../setting/setting',
    })
  }
})