const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    showPhone: false,
    phone: '',
    code: '',
    time: 60,
    animationAddressMenu: {},
    animationStreetMenu: {},
    addressMenuIsShow: false,
    streetMenuIsShow: false,
    value: [0, 0, 0],
    streetvaule: [0],
    provinces: [],
    provinceNum: 0,
    provinceCode: '',
    provinceName: '',
    cityNum: 0,
    citys: [],
    cityCode: '',
    cityName: '',
    countyNum: 0,
    countys: [],
    countyCode: '',
    countyName: '',
    streets: [],
    areas: [],
    province: '',
    city: '',
    area: '',
    display: "none",
    display1: "none",
    currentID: '',
    areaCode: '',
    Address: '',
    street: '',
    roleType: '',
    businessMsg: '',
    isgetCode: true,
    isdefault: false,
    isCode: true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const _this = this;
    // 初始化动画变量
    const animation = wx.createAnimation({
      duration: 500,
      transformOrigin: "50% 50%",
      timingFunction: 'ease',
    })
    _this.animation = animation;
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  /**
   * 输入手机号
   */
  getPhone(e) {
    const _this = this;
    _this.setData({
      phone: e.detail.value
    });
  },
  hidePhone() {
    this.setData({
      showPhone: false,
    })
  },
  /**
   * 输入验证码
   */
  getCode(e) {
    const _this = this;
    const code = e.detail.value
    _this.setData({
      code: code
    })
  },
  hideKeyboard(e) {
    const _this = this;
    const length = e.detail.value.length;
    if (length == 4) {
      wx.hideKeyboard();
      const para = {
        phone: _this.data.phone,
        type: 'busniess',
        vertifyCode: e.detail.value
      };
      // _this.queryRole();
      app.postRequest(app.globalData.api.CheckMessage, para).then((res) => {
        if (res.data.code == '200' && res.data.success) {
          wx.showToast({
            title: res.data.message,
            icon: 'none',
            duration: 1000,
            mask: true
          });
          _this.setData({
            isCode: false
          })
          _this.queryRole();
        } else {
          wx.showToast({
            title: res.data.message,
            icon: 'none',
            duration: 1000,
            mask: true
          })
        }
      });
    }
  },
  /**
   * 获取短信验证码
   */
  getCodeByPhone() {
    const _this = this;
    const phoneExg = /^1[3|4|5|7|8|9][0-9]{9}$/;
    const phone = _this.data.phone;
    if (_this.data.isgetCode) {
      _this.setData({
        isgetCode: false
      });
      if (phone != '') {
        if (phoneExg.test(phone)) {
          // console.log(phoneExg.test(phone));
          _this.setData({
            showPhone: false,
          });
          const para = {
            phone: _this.data.phone,
            type: 'busniess'
          };
          console.log(para);
          let timeCut = 60;
          let timer = setInterval(() => {
            timeCut--;
            _this.setData({
              time: timeCut
            });
            if (timeCut <= 0) {
              _this.setData({
                time: 60
              });
              clearInterval(timer);
              _this.setData({
                isgetCode: true
              });
            }
          }, 1000)
          app.postRequest(app.globalData.api.sendMessage, para).then((res) => {
            if (res.data.code == '200' && res.data.success) {
              wx.showToast({
                title: res.data.message,
                icon: 'none',
                duration: 1000,
                mask: true
              });
            } else {
              wx.showToast({
                title: res.data.message,
                icon: 'none',
                duration: 1000,
                mask: true
              });
              this.setData({
                time: 60,
                isgetCode: true
              });
              clearInterval(timer);
            }
          })
        } else {
          _this.setData({
            showPhone: true,
            checkPhone: '手机号格式错误',
          })
        }
      } else {
        _this.setData({
          showPhone: true,
          checkPhone: '请填写手机号',
        })
      }
    }
  },
  /**
   * 下一步
   */
  next() {
    const _this = this;
    const address = _this.data.Address;
    const street = _this.data.street;
    app.globalData.addressCode = _this.data.addressCode;
    app.globalData.realName = _this.data.realName;
    app.globalData.addressName = _this.data.Address + _this.data.street;
    app.globalData.phone = _this.data.phone;
    if (_this.data.roleType != '') {
      if (_this.data.businessMsg != null) {
        wx.showToast({
          title: _this.data.businessMsg,
          icon: 'none',
          duration: 2000,
          mask: true
        });
      } else {
        if (_this.data.roleType == 1) {
          if (_this.data.type == 1) {
            wx.redirectTo({
              url: '../personalCertificate/personalCertificate',
            })
          } else {
            wx.redirectTo({
              url: '../enterpriseCertificate/enterpriseCertificate',
            })
          }
        } else if (_this.data.roleType == 2) {
          wx.showToast({
            title: '您已是商家，请勿重复申请',
            icon: 'none',
            duration: 1000,
            mask: true
          })
        } else {
          wx.redirectTo({
            url: '../chooseType/chooseType',
          })
        }
      }
    } else {
      if (address.length == 0) {
        wx.showToast({
          title: '请选择地址',
          icon: 'none',
          duration: 1000,
          mask: true
        });
      } else if (street.length == 0) {
        wx.showToast({
          title: '请选择街道',
          icon: 'none',
          duration: 1000,
          mask: true
        });
      } else {
        if (_this.data.isCode) {
          return;
        } else {
          wx.redirectTo({
            url: '../chooseType/chooseType',
          })
        }
      }
    }

  },
  /**
   * 用户角色查询
   */
  queryRole() {
    const _this = this;
    const para = {
      phone: _this.data.phone
    }
    app.postRequest(app.globalData.api.queryRole, para).then((res) => {
      if (res.data.code == '200' && res.data.success) {
        if (res.data.data.roleType == 1) {
          _this.setData({
            isdefault: true
          })
        }
        _this.setData({
          realName: res.data.data.realName,
          Address: res.data.data.countyName,
          street: res.data.data.townName,
          addressCode: res.data.data.addressCode,
          roleType: res.data.data.roleType,
          type: res.data.data.type,
          businessMsg: res.data.data.businessMsg
        })
      } else {
        wx.showToast({
          title: res.data.message,
          icon: 'none',
          duration: 1000,
          mask: true
        })
      }
    });
  },
  /**
   * 初始化地址
   */
  initAddress() {
    const _this = this;
    const value = _this.data.value
    const para = {
      addressLevel: 1
    };
    // 查询省
    app.postRequest(app.globalData.api.queryAddressLinkage, para).then((res) => {
      // console.log(res)
      if (res.data.code === "200" && res.data.success) {
        _this.setData({
          provinces: res.data.data,
          provinceCode: res.data.data[value[0]].addressCode,
          provinceName: res.data.data[value[0]].addressName,
        });
        const paraCity = {
          addressLevel: 2,
          parentId: _this.data.provinceCode
        }
        // 查询市
        app.postRequest(app.globalData.api.queryAddressLinkage, paraCity).then((res) => {
          // console.log(res)
          if (res.data.code === "200" && res.data.success) {
            _this.setData({
              citys: res.data.data,
              cityCode: res.data.data[value[1]].addressCode,
              cityName: res.data.data[value[1]].addressName,
            });
            const paraCounty = {
              addressLevel: 3,
              parentId: _this.data.cityCode
            }
            // 查询区/县
            app.postRequest(app.globalData.api.queryAddressLinkage, paraCounty).then((res) => {
              // console.log(res)
              if (res.data.code === "200" && res.data.success) {
                _this.setData({
                  countys: res.data.data,
                  areaCode: res.data.data[value[2]].addressCode,
                  countyName: res.data.data[value[2]].addressName
                });
                console.log('省code==' + _this.data.provinceCode + '  ' + '市Code==' + _this.data.cityCode + '  ' + '区/县code==' + _this.data.countyCode)
                console.log('省==' + _this.data.provinceName + '    ' + '市==' + _this.data.cityName + '   ' + '区/县' + _this.data.countyName);
                console.log(_this.data.areaCode)
              } else {
                //请求错误处理
              }
            })
          } else {
            //请求错误处理
          }
        })
      } else {
        wx.showToast({
          title: res.data.message,
          icon: 'none',
          duration: 1000,
          mask: true
        });
      }
    })
  },
  //获取地址库 parentId
  queryProvinces: function () {
    const _this = this;
    const data = {
      addressLevel: 1
    };
    app.postRequest(app.globalData.api.queryAddressLinkage, data).then((res) => {
      // console.log(res)
      if (res.data.code === "200" && res.data.success) {
        _this.setData({
          provinces: res.data.data
        })
      } else {
        //请求错误处理
      }
    })
  },
  /**
   * 通过省的code查市
   */
  queryCitys() {
    const _this = this;
    const data = {
      addressLevel: 2,
      parentId: _this.data.provinceCode
    };
    app.postRequest(app.globalData.api.queryAddressLinkage, data).then((res) => {
      // console.log(res)
      if (res.data.code === "200" && res.data.success) {
        _this.setData({
          cuntrys: res.data.data
        })
        console.log(res.data.data);
      } else {
        //请求错误处理
      }
    })

  },
  /**
   * 通过市的code查县/区
   */
  queryCountys() {
    const _this = this;
    const data = {
      addressLevel: 3,
      parentId: _this.data.cityCode
    };
    app.postRequest(app.globalData.api.queryAddressLinkage, data).then((res) => {
      // console.log(res)
      if (res.data.code === "200" && res.data.success) {
        _this.setData({
          countys: res.data.data
        })
        console.log(res.data.data);
      } else {
        //请求错误处理
      }
    })

  },
  /**
   * 通过县区的code查街道
   */
  queryStreets() {
    const _this = this;
    const data = {
      addressLevel: 4,
      parentId: _this.data.areaCode
    };
    app.postRequest(app.globalData.api.queryAddressLinkage, data).then((res) => {
      // console.log(res)
      _this.setData({
        streets: []
      })
      if (res.data.code === "200" && res.data.success) {
        _this.setData({
          streets: res.data.data,
          addressCode: res.data.data[0].addressCode,
          streetName: res.data.data[0].addressName
        })
        // console.log(_this.data.addressCode);
      } else {
        wx.showToast({
          title: res.data.message,
          icon: 'none',
          duration: 1000,
          mask: true
        });
      }
    })

  },
  // 点击所在地区弹出选择框
  getAddress: function (e) {
    const _this = this
    // 如果已经显示，不在执行显示动画
    if (_this.data.addressMenuIsShow) {
      return
    }
    // 执行显示动画
    _this.startAddressAnimation(true)
    _this.initAddress();
  },
  // 点击所在地区弹出选择框
  getStreet() {
    const _this = this
    // 如果已经显示，不在执行显示动画
    if (_this.data.streetMenuIsShow) {
      return
    }
    // 执行显示动画
    _this.startStreetAnimation(true);
    _this.queryStreets();
  },
  // 执行动画 省市区
  startAddressAnimation: function (isShow) {
    var that = this
    if (isShow) {
      // vh是用来表示尺寸的单位，高度全屏是100vh
      that.animation.translateY(0 + 'vh').step();
      //显示遮罩层
      that.setData({
        display: "block"
      })
    } else {
      that.animation.translateY(40 + 'vh').step();
      //隐藏遮罩层
      that.setData({
        display: "none",
        addressMenuIsShow: isShow
      })
    }
    that.setData({
      animationAddressMenu: that.animation.export(),
      addressMenuIsShow: isShow,
    })
  },
  // 执行动画 街道
  startStreetAnimation: function (isShow) {
    var that = this
    if (isShow) {
      // vh是用来表示尺寸的单位，高度全屏是100vh
      that.animation.translateY(0 + 'vh').step();
      //显示遮罩层
      that.setData({
        display1: "block"
      })
    } else {
      that.animation.translateY(40 + 'vh').step();
      //隐藏遮罩层
      that.setData({
        display1: "none",
        streetMenuIsShow: isShow
      })
    }
    that.setData({
      animationStreetMenu: that.animation.export(),
      streetMenuIsShow: isShow,
    })
  },
  // 点击地区选择取消按钮 省市区
  cityCancel: function (e) {
    this.startAddressAnimation(false)
  },
  // 点击地区选择取消按钮 街道
  streetCancel: function (e) {
    this.startStreetAnimation(false)
  },
  // 点击地区选择确定按钮 省市区
  citySure: function (e) {
    const _this = this
    _this.startAddressAnimation(false);
    _this.setData({
      Address: _this.data.provinceName + _this.data.cityName + _this.data.countyName,
      street: ''
    })
  },
  streetSure: function (e) {
    const _this = this
    _this.startStreetAnimation(false);
    _this.setData({
      street: _this.data.streetName
    });
  },
  // 处理省市县联动逻辑
  cityChange: function (e) {
    const _this = this;
    const value = e.detail.value
    const provinceIndex = value[0];                   // 省的索引值  用这个去请求市
    const provinceNum = _this.data.provinceNum;       // 记录省索引值变化
    const cityIndex = value[1];                       // 市的索引值  用这个去请求县/区
    const cityNum = _this.data.cityNum;               // 记录市索引值变化
    const countyIndex = value[2];                       // 县/区的索引值 
    console.log(e);
    if (provinceNum != provinceIndex) {
      _this.setData({
        value: [provinceIndex, 0, 0],
        provinceNum: provinceIndex,
      })
      console.log('我滚动了省')
      // console.log(_this.data.provinceCode);
      _this.setData({
        citys: []
      })
      _this.initAddress();
    } else if (cityNum != cityIndex) {
      console.log(_this.data.citys);
      _this.setData({
        value: [provinceIndex, cityNum, 0],
        cityNum: cityIndex,
        cityCode: _this.data.citys[cityIndex].addressCode,
        cityName: _this.data.citys[cityIndex].addressName,
      })
      console.log('我滚动了市');
      // console.log(_this.data.provinceCode + '  ' + _this.data.provinceName);
      console.log(_this.data.cityCode + '   ' + _this.data.cityName);
      _this.setData({
        countys: []
      })
      _this.queryCountys();
    } else {
      _this.setData({
        value: [provinceIndex, cityNum, countyIndex],
        countyCode: _this.data.countys[countyIndex].addressCode,
        countyName: _this.data.countys[countyIndex].addressName,
        areaCode: _this.data.countys[countyIndex].addressCode
      })
      console.log(_this.data.countyCode + '   ' + _this.data.countyName);
      console.log('我滚动了区/县')
    }
  },
  // 处理街道联动逻辑
  streetChange(e) {
    const _this = this;
    const streetVal = e.detail.value;
    console.log(_this.data.streets);
    _this.setData({
      addressCode: _this.data.streets[streetVal].addressCode,
      streetName: _this.data.streets[streetVal].addressName
    });
  }
})
