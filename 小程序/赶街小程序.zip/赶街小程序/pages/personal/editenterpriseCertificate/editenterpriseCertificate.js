const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    companyName: '',
    realName: '',
    cardNum: '',
    showImgOne: false,
    chooseImgOne: true,
    imgOneUrl: '',
    showImgTwo: false,
    chooseImgTwo: true,
    imgTwoUrl: '',
    showThree: false,
    chooseImgThree: true,
    imgThreeUrl: '',
    allUrl: [],
    loadingOne: false,
    loadingTwo: false,
    loadingThree: false,
    show1: false,
    show2: false,
    show3: false,
    show4: false,
    show5: false,
    show6: false,
    showModal: false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
    const editInfo = JSON.parse(options.editInfo);
    console.log(editInfo);
    const _this = this;
    _this.setData({
      companyName: editInfo.companyName,
      realName: editInfo.realName,
      cardNum: editInfo.cardNum,
      imgOneUrl: editInfo.companyId,
      imgTwoUrl: editInfo.cardFrontId,
      imgThreeUrl: editInfo.cardOppId,
      phone: editInfo.phone,
      userDistrictCode: editInfo.userDistrictCode
    });
    if (_this.data.imgOneUrl != '') {
      _this.setData({
        loadingOne: false,
        showImgOne: true,
        chooseImgOne: false
      })
    };
    if (_this.data.imgTwoUrl != '') {
      _this.setData({
        loadingTwo: false,
        showImgTwo: true,
        chooseImgTwo: false
      })
    };
    if (_this.data.imgThreeUrl != '') {
      _this.setData({
        loadingThree: false,
        showImgThree: true,
        chooseImgThree: false
      })
    }
    console.log(_this.data.imgOneUrl);
  },
  /**
   * 获取法人代表
   */
  getcompanyName(e) {
    const _this = this;
    const name = e.detail.value;
    if (name != '') {
      _this.setData({
        companyName: name
      })
    } else {
      wx.showToast({
        title: '请填法人代表',
        icon: 'none',
        duration: 1000,
        mask: true
      })
    }
  },
  /**
   * 获取企业名称
   */
  getName(e) {
    const _this = this;
    const name = e.detail.value;
    if (name != '') {
      _this.setData({
        realName: name
      })
    } else {
      wx.showToast({
        title: '请填写企业名称',
        icon: 'none',
        duration: 1000,
        mask: true
      })
    }
  },
  /**
  * 获取识别号
  */
  getIdentity(e) {
    const _this = this;
    const identity = e.detail.value
    if (identity != '') {
      _this.setData({
        cardNum: identity
      })
    } else {
      wx.showToast({
        title: '请填写识别号',
        icon: 'none',
        duration: 1000,
        mask: true
      })
    }
  },
  /**
  * 上传第一张图
  */
  chooseOneImg() {
    const _this = this;
    const imgOneUrl = _this.data.imgOneUrl;
    const allUrl = _this.data.allUrl;
    _this.setData({
      loadingOne: true
    });
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        // _this.setData({
        //   imgOneUrl: res.tempFilePaths[0],
        //   showImgOne: true,
        //   chooseImgOne: false
        // })
        // console.log(res.tempFilePaths[0])
        var tempFilePaths = res.tempFilePaths;
        tempFilePaths.forEach((item) => {
          wx.uploadFile({
            // url: 'https://dev.51ganjie.cn/supplyDemand/uploadpic.do', //仅为示例，非真实的接口地址
            url: app.globalData.url + app.globalData.api.uploadPic, //仅为示例，非真实的接口地址
            filePath: item,
            name: 'fileItem',
            header: {
              'content-type': 'multipart/form-data'
            },
            formData: {
              'user': 'test'
            },
            success: function (res) {
              var data = JSON.parse(res.data).data;
              // console.log(data);
              _this.setData({
                loadingOne: false,
                imgOneUrl: data.attachmentUrl,
                showImgOne: true,
                chooseImgOne: false
              })
            }
          })
        })
      }
    });
  },
  /**
  * 上传第二张图
  */
  chooseTwoImg() {
    const _this = this;
    const imgTwoUrl = _this.data.imgTwoUrl;
    _this.setData({
      loadingTwo: true
    });
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        // _this.setData({
        //   imgOneUrl: res.tempFilePaths[0],
        //   showImgOne: true,
        //   chooseImgOne: false
        // })
        // console.log(res.tempFilePaths[0])
        var tempFilePaths = res.tempFilePaths;
        tempFilePaths.forEach((item) => {
          wx.uploadFile({
            // url: 'https://dev.51ganjie.cn/supplyDemand/uploadpic.do', //仅为示例，非真实的接口地址
            url: app.globalData.url + app.globalData.api.uploadPic, //仅为示例，非真实的接口地址
            filePath: item,
            name: 'fileItem',
            header: {
              'content-type': 'multipart/form-data'
            },
            formData: {
              'user': 'test'
            },
            success: function (res) {
              var data = JSON.parse(res.data).data;
              // console.log(data);
              _this.setData({
                loadingTwo: false,
                imgTwoUrl: data.attachmentUrl,
                showImgTwo: true,
                chooseImgTwo: false,
              })
            }
          })
        })
      }
    });
  },
  /**
  * 上传第三张图
  */
  chooseThreeImg() {
    const _this = this;
    const imgThreeUrl = _this.data.imgThreeUrl;
    _this.setData({
      loadingThree: true
    });
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        // _this.setData({
        //   imgOneUrl: res.tempFilePaths[0],
        //   showImgOne: true,
        //   chooseImgOne: false
        // })
        // console.log(res.tempFilePaths[0])
        var tempFilePaths = res.tempFilePaths;
        tempFilePaths.forEach((item) => {
          wx.uploadFile({
            // url: 'https://dev.51ganjie.cn/supplyDemand/uploadpic.do', //仅为示例，非真实的接口地址
            url: app.globalData.url + app.globalData.api.uploadPic,
            filePath: item,
            name: 'fileItem',
            header: {
              'content-type': 'multipart/form-data'
            },
            formData: {
              'user': 'test'
            },
            success: function (res) {
              var data = JSON.parse(res.data).data;
              _this.setData({
                loadingThree: false,
                imgThreeUrl: data.attachmentUrl,
                showImgThree: true,
                chooseImgThree: false,
              })
            }
          })
        })
      }
    });
  },
  delOne() {
    this.setData({
      imgOneUrl: '',
      showImgOne: false,
      chooseImgOne: true,
      allUrl: []
    })
    // console.log(this.data.imgOneUrl);
  },
  delTwo() {
    this.setData({
      imgTwoUrl: '',
      showImgTwo: false,
      chooseImgTwo: true,
      allUrl: []
    })
  },
  delThree() {
    this.setData({
      imgThreeUrl: '',
      showImgThree: false,
      chooseImgThree: true,
      allUrl: []
    })
  },
  /**
  * 查看商家协议
  */
  agreement() {
    wx.navigateTo({
      url: '../agreement/agreement',
    })
  },
  /**
  * 提交认证
  */
  commit() {
    const _this = this;
    const approveStatus = 1;
    if (_this.data.companyName == '') {
      wx.showToast({
        title: '请填法人代表',
        icon: 'none',
        duration: 1000,
        mask: true
      });
      return;
    };
    if (_this.data.realName == '') {
      wx.showToast({
        title: '请填写企业名称',
        icon: 'none',
        duration: 1000,
        mask: true
      });
      return;
    };
    if (_this.data.cardNum == '') {
      wx.showToast({
        title: '请填写识别号',
        icon: 'none',
        duration: 1000,
        mask: true
      });
      return;
    };
    if (_this.data.imgOneUrl == '') {
      wx.showToast({
        title: '请上传营业执照',
        icon: 'none',
        duration: 1000,
        mask: true
      });
      return;
    };
    if (_this.data.imgTwoUrl == '') {
      wx.showToast({
        title: '请上传身份证正面',
        icon: 'none',
        duration: 1000,
        mask: true
      });
      return;
    };
    if (_this.data.imgThreeUrl == '') {
      wx.showToast({
        title: '请上传身份证背面',
        icon: 'none',
        duration: 1000,
        mask: true
      });
      return;
    }
    const para = {
      type: 2,
      companyName: _this.data.companyName,
      realName: _this.data.realName,
      cardNum: _this.data.cardNum,
      companyId: _this.data.imgOneUrl,
      cardFrontId: _this.data.imgTwoUrl,
      cardOppId: _this.data.imgThreeUrl,
      userDistrictCode: _this.data.userDistrictCode,
      phone: _this.data.phone,
      token: app.globalData.token,
      unionId: app.globalData.userInfo.unionId
    };
    console.log(para);
    app.postRequest(app.globalData.api.insert, para).then((res) => {
      if (res.data.code == '200' && res.data.success) {
        console.log(res);
        wx.redirectTo({
          url: `../auditStatus/auditStatus?approveStatus=${approveStatus}`
        })
      } else {
        wx.showToast({
          title: res.data.message,
          icon: 'none',
          duration: 1000,
          mask: true
        })
      }
    })
  }
})