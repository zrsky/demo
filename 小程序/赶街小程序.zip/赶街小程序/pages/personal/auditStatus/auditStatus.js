const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    approveStatus: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options);
    const _this = this;
    _this.setData({
      approveStatus: options.approveStatus
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },
  /**
   * 复制网址
   */
  copyUrl(e) {
    const _this = this;
    wx.setClipboardData({
      data: 'http://bm.51ganjie.cn',
      success: function (res) {
        wx.showToast({
          title: '复制成功',
          duration: 1000,
          mask: true
        })
      }
    })
  },
  /**
   * 联系客服
   */
  callService() {
    wx.makePhoneCall({
      phoneNumber: '4000086600',
    })
  },
  /**
   * 获取重新申请数据
   */
  reapply() {
    const _this = this;
    const para = {
      unionId: app.globalData.userInfo.unionId,
      token: app.globalData.token
    };
    app.postRequest(app.globalData.api.queryByCondition, para).then((res) => {
      console.log(res.data);
      if (res.data.code == '200' && res.data.success) {
        if( res.data.data.type == 1 ) {
          const deitJson = {
            cardFrontId: res.data.data.cardFrontId,
            cardHandId: res.data.data.cardHandId,
            cardOppId: res.data.data.cardOppId,
            realName: res.data.data.realName,
            cardNum: res.data.data.cardNum,
            userDistrictCode: res.data.data.userDistrictCode,
            phone: res.data.data.phone,
            type: res.data.data.type
          }
          console.log(deitJson);
          const editInfo = JSON.stringify(deitJson);
          wx.redirectTo({
            url: `../editpersonalCertificate/editpersonalCertificate?editInfo=${editInfo}`
          })
        }else {
          const deitJson = {
            cardFrontId: res.data.data.cardFrontId,
            companyId: res.data.data.companyId,
            cardOppId: res.data.data.cardOppId,
            cardNum: res.data.data.cardNum,
            companyName: res.data.data.companyName,
            realName: res.data.data.realName,
            userDistrictCode: res.data.data.userDistrictCode,
            phone: res.data.data.phone,
            type: res.data.data.type
          }
          const editInfo = JSON.stringify(deitJson);
          wx.redirectTo({
            url: `../editenterpriseCertificate/editenterpriseCertificate?editInfo=${editInfo}`
          })
        }
      } else {
        wx.showToast({
          title: res.data.message,
          icon: 'none',
          duration: 1000,
          mask: true
        })
      }
    })
  }
})