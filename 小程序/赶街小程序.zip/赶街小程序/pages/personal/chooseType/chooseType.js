Page({

  /**
   * 页面的初始数据
   */
  data: {
    chooseType: [
      {
        type: 1,
        name: '个人认证'
      },
      {
        type: 2,
        name: '企业认证'
      }
    ],
    index: 0, 
    type: 1
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },
  /**
   * 选择认证类型
   */
  bindPickerChange: function (e) {
    const _this = this;
    _this.setData({
      index: e.detail.value,
      type: _this.data.chooseType[e.detail.value].type
    })
  },
  /**
   * 下一步
   */
  next() {
    const _this = this;
    const type = _this.data.type;
    if (type == 1) {    // 个人
      wx.redirectTo({
        url: '../personalCertificate/personalCertificate'
      })
    }else {
      wx.redirectTo({
        url: '../enterpriseCertificate/enterpriseCertificate',
      })
    }
  }
})