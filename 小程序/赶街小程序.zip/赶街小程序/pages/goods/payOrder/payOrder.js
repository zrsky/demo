/* 订单支付 */
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    goodsImgUrl: '',
    name: '',
    skuStr: '',
    tradeNo: '',
    price: '',
    payStatus: true,
    num: 0,
    goodList: [],
    payOrder: false
  },
  //支付
  payOrder() {
    let _this = this;
    _this.data.payOrder = true;
    if (_this.data.payStatus) {
      _this.setData({
        payStatus: false
      })
      const data = {
        tradeNo: _this.data.tradeNo,
        amount: _this.data.price,
        token: app.globalData.token
      }
      app.postRequest(app.globalData.api.payOrder, data).then((res) => {
        wx.requestPayment({
          timeStamp: res.data.data.timeStamp,
          nonceStr: res.data.data.nonceStr,
          package: res.data.data.package,
          signType: 'MD5',
          paySign: res.data.data.paySign,
          success: function (res) {
            wx.redirectTo({
              url: '../payOrderResult/payOrderResult?tradeNo=' + _this.data.tradeNo,
            })
          },
          fail: function (res) {
            wx.redirectTo({
              url: '../../personal/myOrderList/myOrderList?id=1&payOrder=1',
            })
          },
          complete: function () {
            _this.setData({
              payStatus: true
            })
          }
        });
      })
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let _this = this, obj = JSON.parse(options.obj);
    _this.setData({
      // goodsImgUrl: obj.goodsImgUrl,
      // name: obj.name,
      // skuStr: obj.skuStr,
      tradeNo: obj.orderNo,
      price: obj.price,
      // num: obj.num
      goodList: obj.goodList
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    if (!this.data.payOrder == true) {
      wx.navigateBack({
        delta: 1
      })
    }
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
