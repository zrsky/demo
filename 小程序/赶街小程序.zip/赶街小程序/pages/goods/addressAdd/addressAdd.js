// 添加收货地址
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    addressObj:{},
    region: [{
      provinceName: '',
      provinceCode: '',
      cityName: '',
      cityCode: '',
      countyName: '',
      countyCode: ''
    }],//省市区
    token:'',
    //表单校验
    checkName:'姓名不能为空',
    checkPhone:'',
    checkAreaStr:'省市县不能为空',
    checkAddress:'详细地址不能为空',
    checkNameStatus: false,
    checkPhoneStatus: false,
    checkAreaStrStatus: false,
    checkAddressStatus: false,
    action:'',
    payStatus: true,
    province:{},//临时地址存储
    city: {},//临时地址存储
    county: {},//临时地址存储
    addressRegion:[],//地址回显
    showStatus:false,//弹框判断
    parentCode:'',//父级地址code
    level:1,//地址层级
    cityStatus:false,//市级显示状态
    countyStatus:false//县级显示状态
  },

  //查询地址
  queryAddress() {
    let _this = this;
    let level = _this.data.level;
    const data = {
      addressLevel: level
    }
    if (level != 1) {
      data.parentId = _this.data.parentCode
    }
    if (level <=3) {
      app.postRequest(app.globalData.api.queryAddressLinkage, data).then((res) => {
        if (res.data.code === "200" && res.data.success) {
          _this.setData({
            addressRegion: res.data.data
          })
        } else {
          //请求错误处理
        }
      })
    } else {

    }
  },
  //选择省市县
  chooseType(e) {
    let data = e.currentTarget.dataset.text;
    this.setData({
      level :data.addressLevel
    })
    if (data.addressLevel == 1) {
      this.setData({
        cityStatus: false,
        countyStatus: false,
      })
    } else if (data.addressLevel == 2) {
      this.setData({
        cityStatus: true,
        countyStatus: false,
        parentCode: data.parentId
      })
    } else {
      this.setData({
        cityStatus: true,
        countyStatus: true,
        parentCode: data.parentId
      })
    }
    this.queryAddress();
  },

  //省市县切换
  switchAddress(e) {
    let data = e.currentTarget.dataset.text;
    let level = data.addressLevel + 1;
    let obj = {
      parentId:data.parentId,
      addressName:data.addressName,
      addressCode:data.addressCode,
      addressLevel: level-1
    };
    if(level == 2) {
      this.setData({
        cityStatus : true,
        countyStatus : false,
        province : obj
      })
    } else if (level == 3) {
      this.setData({
        cityStatus : true,
        countyStatus : true,
        city : obj
      })
    } else if (level == 4) {
      this.setData({
        cityStatus: true,
        countyStatus: true,
        county: obj
      })
    }
    this.setData({
      parentCode: data.addressCode,//父级地址code
      level: level
    })
  
    this.queryAddress();
  },

  //打开弹框
  openShowAddress() {
    //初始化省市县
    let province={},city={},county={};
    if (this.data.addressObj.areaStr == undefined || this.data.addressObj.areaStr == "") {
      province = {
        parentId: '',
        addressName: '省',
        addressCode: '',
        addressLevel: 1
      },
        city = {
          parentId: '',
          addressName: '市',
          addressCode: '',
          addressLevel: 2
        },
        county = {
          parentId: '',
          addressName: '县',
          addressCode: '',
          addressLevel: 3
        };
        this.setData({
          province: province,
          city: city,
          county: county,
          showStatus: true,
          level: 1,
          cityStatus: false,
          countyStatus: false,
        })
    } else {
      this.setData({
        showStatus: true,
        level: 3,
        parentCode: this.data.city.addressCode,
        cityStatus: true,
        countyStatus: true,
      })
    }
    this.queryAddress();
  },

  //关闭弹框
  closeShowAddress() {
    this.setData({
      showStatus : false
    })
    let addressObjAreaStr = "addressObj.areaStr";
    if(this.data.county.addressCode != '') {
      this.setData({
        [addressObjAreaStr]: this.data.province.addressName + this.data.city.addressName + this.data.county.addressName
      })
    } else {
      
    }
  },

  //表单校验
  checkName(e) {
    if (e.detail.value === "") {
      this.setData({
        checkNameStatus:true,
      })
    } else {
      let addressObjName = "addressObj.name";
      this.setData({
        checkNameStatus:false,
        [addressObjName] : e.detail.value
      })
    }
  },
  checkPhone(e) {
    let addressObjPhone = "addressObj.telephone";
    if (e.detail.value === "") {
      this.setData({
        checkPhoneStatus: true,
        checkPhone: '手机号不能为空',
        [addressObjPhone]: e.detail.value
      })
    } else {
      let myreg = /^[1][3,4,5,7,8][0-9]{9}$/;
      if (!myreg.test(e.detail.value)) {
        this.setData({
          checkPhoneStatus: true,
          checkPhone: '手机号格式不正确',
          [addressObjPhone]: e.detail.value
        })
      } else {
        this.setData({
          checkPhoneStatus: false,
          [addressObjPhone]: e.detail.value
        })
      }
    }
  },
  checkAddress(e) {
    let addressObjAddress = "addressObj.address";
    if (e.detail.value === "") {
      this.setData({
        checkAddressStatus: true,
        [addressObjAddress]: e.detail.value
      })
    } else {
      this.setData({
        checkAddressStatus: false,
        [addressObjAddress]: e.detail.value
      })
    }
  },

  //新增地址
  addressAdd() {
    let _this = this,flag = true;
    if (_this.data.payStatus) {
      _this.setData({
        payStatus: false
      })
      //提交时校验name是否为空
      if (_this.data.addressObj.name === "" || _this.data.addressObj.name === undefined) {
        this.setData({
          checkNameStatus: true,
        })
        flag = false;
      }
      //提交时校验手机号
      let myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
      if (_this.data.addressObj.telephone === "" || _this.data.addressObj.telephone === undefined) {
        this.setData({
          checkPhoneStatus: true,
          checkPhone: '手机号不能为空'
        })
        flag = false;
      } else {
        if (!myreg.test(_this.data.addressObj.telephone)) {
          this.setData({
            checkPhoneStatus: true,
            checkPhone: '手机号格式不正确'
          })
          flag = false;
        }else{
          flag = true;
        }
      }
      //提交时校验省市县是否为空
      if (_this.data.addressObj.areaStr === "") {
        this.setData({
          checkAreaStrStatus: true,
        })
        flag = false;
      }
      //提交时校验address是否为空
      if (_this.data.addressObj.address === "" || _this.data.addressObj.address === undefined) {
        this.setData({
          checkAddressStatus: true,
        })
        flag = false;
      }
      if(flag) {
        let data = {
          name: _this.data.addressObj.name,
          showAddress: _this.data.addressObj.areaStr,
          telephone: _this.data.addressObj.telephone,
          address: _this.data.addressObj.address,
          postalCode: '',
          provinceCode: _this.data.province.addressCode,
          cityCode: _this.data.city.addressCode,
          countyCode: _this.data.county.addressCode,
          provinceName: _this.data.province.addressName,
          cityName: _this.data.city.addressName,
          countyName: _this.data.county.addressName,
          token:app.globalData.token,
          isDefault: 0
        },url = "";
        if(_this.data.action === "update") {
          data.addressId = _this.data.addressObj.addressId;
          url = app.globalData.api.updateAddress
        } else {
          url = app.globalData.api.addAddress
        }
        app.postRequest(url,data).then((res) => {
          if (res.data.code === "200" && res.data.success) {
            wx.navigateBack({
              url: '../addressList/addressList',
              delta:1,
              success() {
                _this.setData({
                  payStatus: true
                })
              }
            })
          } else {
            _this.setData({
              payStatus: true
            })
            wx.showToast({
              title: res.data.message,
              icon: 'none'
            })
          }
        })
      }
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let _this = this,action = options.action;
    _this.setData({
      action:action
    })
    if(action == 'update') {
      let obj = JSON.parse(options.addressObj);
      let areaStr = obj.provinceName + obj.cityName + obj.countyName,
        addressObjAreaStr = "addressObj.areaStr",
      province = {
        addressName: obj.provinceName,
        addressCode: obj.provinceCode,
        addressLevel: 1
      },
        city = {
          parentId: obj.provinceCode,
          addressName: obj.cityName,
          addressCode: obj.cityCode,
          addressLevel: 2
        },
        county = {
          parentId: obj.cityCode,
          addressName: obj.countyName,
          addressCode: obj.countyCode,
          addressLevel: 3
        };
      this.setData({
        province: province,
        city: city,
        county: county,
        showStatus: false,
        level: 3,
        cityStatus: true,
        countyStatus: true,
      })
      _this.setData({
        addressObj: JSON.parse(options.addressObj),
        [addressObjAreaStr]: areaStr
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})