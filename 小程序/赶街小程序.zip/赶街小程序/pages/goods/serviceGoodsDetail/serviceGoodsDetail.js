// 服务类商品
const app = getApp();
var WxParse = require("../../../utils/wxParse/wxParse.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    goodsInfo: null,
    bizId: '',
    shareType: '',
    goodsDetailStatus: false
  },
  /**
   * 生命周期函数--监听页面加载
   */
  jumpGoodList() {
    wx.redirectTo({
      url: '../goodsList/goodsList',
    })
  },
  onLoad: function (options) {
    this.setData({
      bizId: options.id
    });
    //获取分享类型
    let type = app.globalData.shareType;
    this.setData({
      shareType: type
    })
    this.getGoodsInfo();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    let _this = this;
    let userId = '';
    if (app.globalData.userId != '') {
      userId = app.globalData.userId;
    } else {
      userId = '';
    }

    return {
      title: _this.data.goodsInfo.goodsTitle,
      desc: '',
      imageUrl: _this.data.goodsInfo.imgUrls[0],
      path: '/pages/entry/entry?userId=' + userId + "&bizId=" + _this.data.bizId + "&shareType=wxGoods&sourceType=" + _this.data.goodsInfo.sourceType,
      success: (res) => {
        //分享日志
        const data = {
          shareUserId: app.globalData.userInfo.userId,
          shareType: 4
        }
        app.postRequest(app.globalData.api.shareLog, data).then((res) => {
          console.log(res);
        })
      }
    }
  },
  /**
   * 获取服务类商品详情
   */
  getGoodsInfo() {
    const _this = this;
    const para = {
      // bizId: "SPGD2018062915531",
      bizId: _this.data.bizId
    }
    app.postRequest(app.globalData.api.queryGoodsDetails, para).then((res) => {
      if (res.data.code === "200" && res.data.success) {
        if (res.data.data != null) {
          _this.setData({
            goodsInfo: res.data.data
          })
          let goodsDetailStatus = false;
          if (res.data.data.isPublish == 0) {
            goodsDetailStatus = true
          } else {
            goodsDetailStatus = false
          }
          _this.setData({
            goodsDetailStatus: goodsDetailStatus
          })
          let info = res.data.data.goodsVO.infos;
          let reg = /<h2hiragino>([\S\s\t]*?)<\/h2hiragino>/g
          let info1 = info.replace(reg, '');
          let infoArr = [];
          if (info1.indexOf("<!--[if gte mso 9]>") > -1) {
            let info2 = info.split("<!--[if gte mso 9]>");
            info1 = info2[0];
          }
          if (res.data.data.bizId == "SPGD2018071010052") {
            info1 = info1 + `<font color="#46acc8"><font face="宋体">工作地址：广东省中山市南头镇南头大道西59号</font>`; 
          }
          WxParse.wxParse('goodsDetails', 'html', info1, _this, 5);
        } else {
          wx.showToast({
            title: '暂无数据，重新加载',
          })
        }
      }
    })
  },
  /**
   * 联系我们
   */
  callSeller() {
    const _this = this;
    wx.makePhoneCall({
      phoneNumber: _this.data.goodsInfo.goodsVO.sellerPhone
    })
  },
  /**
   * 立即报名
   */
  apply() {
    const _this = this;
    const gdBizId = _this.data.goodsInfo.goodsVO.bizId
    wx.navigateTo({
      url: `../apply/apply?gdBizId=${gdBizId}`,
    })
  },
  //跳转到首页
  jumpIndex() {
    wx.reLaunch({
      url: '../goodsList/goodsList',
    })
  },

  //跳转到店铺页
  jumpStore() {
    wx.navigateTo({
      url: '../store/store?id=' + app.globalData.userId,
    })
  },
})