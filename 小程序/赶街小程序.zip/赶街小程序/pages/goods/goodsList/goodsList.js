//index.js
//获取应用实例
const app = getApp()
var bmap = require("../../../utils/bmap-wx.min.js");
var wxMarkerData = [];  //定位成功回调对象 

Page({
  data: {
    address:{}, 
    flag: false,
    listData:[],
    category:[],
    categoryBizId:'',
    cateStatus:-1,
    pageSize:10,
    pageNo:0,
    payStatus: true,
    tabBar:[],
    recommendStatus:true,
    toView: ''
  },

  //地址定位切换
  addressSwitch() {
    var _this = this;
    // //新建百度地图对象
    // var BMap = new bmap.BMapWX({
    //   ak: "em0KzAqoQ9IBuzBoQc1dDWkOwcFkrAWw"
    // });
    // var success = function (data) {
    //   //通过百度api获取当前位置信息
    //   let addressData = {};
    //   addressData.name = data.originalData.result.addressComponent.district;
    //   addressData.code = data.originalData.result.addressComponent.adcode;
    //   app.globalData.positionAddress = addressData;
    //   let cancelData = {
    //     name: '请选择地址信息',
    //     code: '000000',
    //   };
      //从微信缓存中拿取访问过的地址信息
      wx.getStorage({
        key: 'addressStorage',
        success: function (res) {
          let item = res.data;
            _this.setData({
              address: item[0]
            });
            //存入全局地址变量中
            app.globalData.currentAddress = item[0];
            //查询商品
            _this.queryCategoryList();
            _this.queryGoods(1);
        },
        fail: function (res) {
          //当前地址赋值
          _this.setData({
            address: app.globalData.positionAddress
          });
          //存入全局地址变量中
          app.globalData.currentAddress = app.globalData.positionAddress;
          //存入缓存
          let arr = [];
          arr.unshift(app.globalData.positionAddress);
          wx.setStorageSync('addressStorage', arr);
           //查询商品
          _this.queryCategoryList();
          _this.queryGoods(1);
        }
      })
    // }
    // var fail = function (data) {
    //   // wx.showToast({
    //   //   title: '地址切换失败',
    //   // })
    // }
    // BMap.regeocoding({
    //   fail: fail,
    //   success: success
    // });
  },

  //选择商品类目
  chooseCategory(e) {
    let _this = this;
    let index = e.currentTarget.dataset.index, text = e.currentTarget.dataset.text;
    if(index == -1) {
      _this.setData({
        cateStatus: index,
        recommendStatus: true,
        pageNo: 0
      })
    } else {
      _this.setData({
        cateStatus: index,
        categoryBizId: text.bizId,
        recommendStatus: false,
        pageNo: 0
      })
    }
    _this.queryGoods(1);
  },

  //查询所有商品
  queryGoods(type) {
    let _this = this;
    const data = {
      token:app.globalData.token,
      type:type,
      userBizId:app.globalData.userInfo.openId,
      areaCode: app.globalData.currentAddress.code,
      pageNo:_this.data.pageNo,
      pageSize:_this.data.pageSize
    }
    console.log(_this.data.recommendStatus)
    if(_this.data.recommendStatus) {
      data.sortType = 'recommend'
    } else {
      data.sortType = ''
      data.categoryBizId = _this.data.categoryBizId
    }
    app.postRequest(app.globalData.api.queryGoodsPage, data).then((res) => {
      if(res.data.code === "200") {
        if (res.data.data.totalCount > 0){
          let list = res.data.data.data,arr = _this.data.listData;
          if(type === 1) {
            arr = [];
          }
          // console.log(list);
          if (list != null) {
            list.forEach((item) => {
              let image = item.imgUrl.split(','),addressArr = [];
              if(item.areaAdress != null) {
                if (item.areaAdress.indexOf(",") != -1) {
                  addressArr = item.areaAdress.split(",");
                  addressArr.pop();
                } else {
                  addressArr = item.areaAdress;
                }
              }
              arr.push({
                bizId: item.bizId,
                img: image[0],
                name: item.goodsTitle,
                sellPoint: item.feature,
                price: item.platSalePrice,
                sales: item.saleQuantity,
                sourceType: item.sourceType,
                address: addressArr,
                template: item.template
              })
            })
            wx.stopPullDownRefresh();
            _this.setData({
              listData: arr
            })
          } else {
            if(_this.data.pageNo === 0) {
              //页面显示无商品的图片
              _this.setData({
                listData: arr
              })
              wx.showToast({
                title: '暂无商品',
                icon: 'none'
              })
            } else {
              wx.showToast({
                title: '已经滑到底了！！！',
                icon: 'none'
              })
            }
          }
        }else {
          _this.setData({
            listData: []
          })
          wx.showToast({
            title: '暂无商品',
            icon: 'none'
          })
        }
      } else {
        wx.showToast({
          title: res.data.message,
          icon: 'none'
        })
      }
    })
  },
  //跳转到商品详情
  jumpGoodDetail(e) {
    let _this = this;
    if (_this.data.payStatus) {
      _this.setData({
        payStatus: false
      })
      let goods = e.currentTarget.dataset.text;
      if(goods.sourceType === 7) {
        wx.navigateTo({
          url: '../serviceGoodsDetail/serviceGoodsDetail?id=' + goods.bizId,
          complete() {
            _this.setData({
              payStatus: true
            })
          }
        })
      } else {
        wx.navigateTo({
          url: '../goodsDetail/goodsDetail?id=' + goods.bizId + "&shareType=wx",
          complete() {
            _this.setData({
              payStatus: true
            })
          }
        })
      }
    }
  },

  //首页查询所有商品类目
  queryCategoryList() {
    let _this = this;
    const data ={
      token:app.globalData.token,
      areaCode:app.globalData.currentAddress.code
    };
    app.postRequest(app.globalData.api.queryCategoryList, data).then((res) => {
      if(res.statusCode == '200') {
        let data = res.data.data
        data.forEach((item,index) => {
          item.id = 'd' + index;
        })
        _this.setData({
          category:data
        })
        this.changeToView()
      }
    })
  },
  changeToView() {
    this.setData({
      toView: this.data.toView
    })
  },
  //事件处理函数
  onLoad: function (options) {
    this.setData({
      recommendStatus: JSON.parse(options.recommendStatus),
      cateStatus: options.cateStatus,
      categoryBizId: options.categoryBizId ? options.categoryBizId : null,
    })
    this.data.toView= options.id.trim() || '';
  },

  onShow: function () {
    this.setData({
      address: app.globalData.currentAddress
    });
    this.addressSwitch();
  },

  //页面上拉触底事件处理
  onReachBottom:function () {
    let _this = this;
    _this.setData({
      pageNo:_this.data.pageNo + 1,
    })
    _this.queryGoods(2);
  },

  //页面下拉处理
  onPullDownRefresh:function () {
    console.log(546)
    let _this = this;
    _this.setData({
      pageNo:0
    })
    this.queryGoods(1);
  }
})
