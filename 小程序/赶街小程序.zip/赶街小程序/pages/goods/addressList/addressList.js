// pages/goods/goodsList.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {  
    addressList:[],
    isCenter:false,
    noData: false
  },

  //跳转至添加地址页面2
  jumpAddressAdd() {
    wx.navigateTo({
      url: "../addressAdd/addressAdd?action=add",
    })
  },

  //跳转至添加地址页面（修改）
  jumpAddressUpdate(e) {
    let addressObj = e.currentTarget.dataset.text;
    let addressObjReal = JSON.stringify(addressObj);
    wx.navigateTo({
      url: "../addressAdd/addressAdd?action=update&addressObj=" + addressObjReal
    })
  },

  //查询所有收获地址
  queryAddressList() {
    let _this = this;
    const data = {
      token: app.globalData.token
    }
    app.postRequest(app.globalData.api.queryAddress,data).then((res) => {
      // console.log(res.data);
        if(res.data.code === "200" && res.data.success) {
          if(res.data.data.length != 0) {
            _this.setData({
              addressList: res.data.data,
              noData: false
            })
          }else {
            _this.setData({
              addressList: res.data.data,
              noData: true
            })
            // let pages = getCurrentPages();
            // let prevPage = pages[pages.length - 2];  //上一个页面

            // prevPage.setData({
            //   addressId: ''
            // })
          }
        } else {
          wx.showToast({
            title: res.data.message,
          })
        }
    })
  },

  //设置默认
  chooseRadio(e) {
    let _this = this;
    let addressId = e.currentTarget.dataset.text.addressId;
    const data = {
      addressId : addressId,
      isDefault : 1,
      token: app.globalData.token
    }
    app.postRequest(app.globalData.api.defaultAddress, data).then((res) => {
      if (res.data.code === "200" && res.data.success) {
        _this.queryAddressList();
      }
    })
  },

  //删除收货地址
  deleteAddress(e) {
    let _this = this;
    wx.showModal({
      title: '是否删除该收货地址？',
      content: '',
      success: function (res) {
        if (res.confirm) {
          let addressId = e.currentTarget.dataset.text.addressId;
          const data = {
            addressId: addressId,
            isDefault: 1,
            token: app.globalData.token
          }
          app.postRequest(app.globalData.api.deleteAddress, data).then((res) => {
            if (res.data.code === "200" && res.data.success) {
              wx.showToast({
                title: '删除成功',
              })
              _this.queryAddressList();
            }
          })
        }else if (res.cancel) {

        }
      }
    })
  },

  //跳转至确认订单模块
  jumpConfirmOrders(e) {
    let pages = getCurrentPages();
    let prevPage = pages[pages.length - 2];  //上一个页面

      prevPage.setData({
        addressId: e.currentTarget.dataset.text
      })
    
    wx.navigateBack({
      delta:1,
      url: '../confirmOrders/confirmOrders',
    })
  },

  jumpPersonal() {
    wx.switchTab({
      url: "../../personal/personalCenter/personalCenter",
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let _this = this;
    if (options.isCenter == 'isCenter') {
      _this.setData({
        isCenter: true
      })
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.queryAddressList();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      title:'微信小',
      desc:'见覅诶房间诶',
      path:'/page/goods/goodsList.wxml'
    }
  }
})