//index.js
//获取应用实例
const app = getApp()
var bmap = require("../../../utils/bmap-wx.min.js");
var wxMarkerData = [];  //定位成功回调对象 
Page({
  data: {
    address:{}, 
    flag: true,
    listData:[],
    shopName:'',
    areaName:'',
    photo:'',
    photoStatus:false,
    pageSize:10,
    pageNo:0,
    tabBar: [],
    category: [],
    categoryBizId:'',
    cateStatus: -1,
    // recommendStatus: true,
    status:false
  },

  //选择商品类目
  chooseCategory(e) {
    let _this = this;
    let index = e.currentTarget.dataset.index, text = e.currentTarget.dataset.text;
    // if (index == -1) {
    //   _this.setData({
    //     cateStatus: index,
    //     recommendStatus: true,
    //     pageNo: 0
    //   })
    // } else {
      _this.setData({
        cateStatus: index,
        categoryBizId: text.bizId,
        recommendStatus: false,
        pageNo: 0
      })
    // }
    _this.queryStoreGoods(1);
  },

  //查询所有商品类目
  queryListCategoryList() {
   let _this = this;
   const data = {
    //  userId:'AU2018080814559'
     userId:app.globalData.userId
   }
    app.postRequest(app.globalData.api.queryListCategoryList, data).then((res) => {
        if(res.data.code == '200' && res.data.success) {
          let status = false;
          if(res.data.data.length>0) {
            status = false;
          } else {
            status = true;
          }
          _this.setData({
            category:res.data.data,
            status: status,
            cateStatus:0,
            categoryBizId:res.data.data[0].bizId
          })
        }
      this.queryStoreGoods(1);
    })
  },

  //查询所有商品
  queryStoreGoods(type) {
    let _this = this;
    const data = {
      // appUserId:'AU2018080814559',
      appUserId:app.globalData.userId,
      pageNo:_this.data.pageNo,
      pageSize:_this.data.pageSize
    }
    //隐藏精选模块
    // if (_this.data.recommendStatus) {
    //   data.sortType = 'recommend'
    // } else {
      data.sortType = ''
      data.categoryBizId = _this.data.categoryBizId
    // }
    app.postRequest(app.globalData.api.queryStoreGoods, data).then((res) => {
      console.log(res);
      if(res.data.code === "200" && res.data.success > 0) {
        let item = res.data.data;
        if(item.photo === '' || item.photo == undefined) {
          _this.setData({
            photoStatus:false
          })
        }else {
          _this.setData({
            photoStatus: true
          })
        }
        _this.setData({
          shopName: item.shopName,
          areaName: item.codeName,
          photo: item.photo
        })
        if(item.pager.totalCount >0) {
          let list = item.pager.data,arr = _this.data.listData;
          if (type === 1) {
            arr = [];
          }
          if (list != null) {
            list.forEach((response) => {
              let item = response.data;
              let image = item.imgUrl.split(','),addressArr = [];
              if(item.areaAdress != null) {
                if (item.areaAdress.indexOf(",") != -1) {
                  addressArr = item.areaAdress.split(",");
                  addressArr.pop();
                } else {
                  addressArr = item.areaAdress;
                }
              }
              arr.push({
                bizId: item.bizId,
                img: image[0],
                name: item.goodsTitle,
                sellPoint: item.feature,
                price: item.platSalePrice,
                sales: item.saleQuantity,
                sourceType: item.sourceType,
                address: addressArr
              })
            })
            wx.stopPullDownRefresh();
            _this.setData({
              listData: arr
            })
          } else {
            if (_this.data.pageNo === 0) {
              //页面显示无商品的图片
              _this.setData({
                listData: arr
              })
              wx.showToast({
                title: '暂无商品',
                icon: 'none'
              })
            } else {
              wx.showToast({
                title: '已经滑到底了！！！',
              })
            }
          }
        } else {
          _this.setData({
            listData: []
          })
          wx.showToast({
            title: '暂无商品',
            icon: 'none'
          })
        }
      } else {
        wx.showToast({
          title: res.data.message,
          icon: 'none'
        })
      }
    })
  },
  //跳转至商品详情
  jumpGoodDetail(e) {
    let goods = e.currentTarget.dataset.text;
    if(goods.sourceType === 7) {
      wx.navigateTo({
        url: '../serviceGoodsDetail/serviceGoodsDetail?id=' + goods.bizId
      })
    } else {
      wx.navigateTo({
        url: '../goodsDetail/goodsDetail?id=' + goods.bizId
      })
    }
  },
  jumpGoodList() {
    wx.redirectTo({
      url: '../goodsList/goodsList',
    })
  },
  //初始化底部导航
  initTabBar() {
    let _this = this;
    let tabBar = app.globalData.tabBar, index = 1;
    if(tabBar.length <3) {
      let arr = {
        "pagePath": "../../../pages/goods/store/store",
        "text": "店铺",
        "iconPath": "../../../img/tabBar/menu_store_off.png",
        "selectedIconPath": "../../../img/tabBar/menu_store_on.png",
        "active": false
      };
      tabBar.splice(1,0,arr)
    }
    for (let i = 0; i < tabBar.length; i++) {
      if (!tabBar[i].active && i == index) {
        let t = tabBar[i].iconPath;
        tabBar[i].iconPath = tabBar[i].selectedIconPath;
        tabBar[i].selectedIconPath = t;
        tabBar[i].active = true;
      } else if (tabBar[i].active && i != index) {
        let t = tabBar[i].iconPath;
        tabBar[i].iconPath = tabBar[i].selectedIconPath;
        tabBar[i].selectedIconPath = t;
        tabBar[i].active = false;
      }
    }
    this.setData({
      tabBar: tabBar
    })
  },
  //底部导航跳转
  jumgPages(e) {
    let tabBar = e.currentTarget.dataset.text;
    wx.redirectTo({
      url: tabBar.pagePath,
    })
  },
  //事件处理函数
  onLoad: function () {
    app.globalData.shareType = 3;
    this.queryListCategoryList();
    this.initTabBar();
  },
  onReady: function () {
  },

  //页面上拉触底事件处理
  onReachBottom:function () {
    let _this = this;
    _this.setData({
      pageNo:_this.data.pageNo + 1,
    })
    _this.queryStoreGoods(2);
  },

  //页面下拉处理
  onPullDownRefresh:function () {
    let _this = this;
    _this.setData({
      pageNo:0
    })
    this.queryStoreGoods(1);
  }
})