// pages/goods/goodsList.js
import { AddressPanel } from '../../../component/address/address'
const app = getApp();
Page(Object.assign({}, AddressPanel,{
  /**
   * 页面的初始数据
   */
  data: {
    goodsImgUrl:'',
    name:'',
    sellerName:'',
    price:0,
    num:1,
    amountPrice:0,
    inventory:0,
    orderGoods:{},
    skuCode:'',
    skuStr: {},
    imageId:'',
    goodsCode:'',
    payStatus: true,
    mark: 0,
    addressInfo: null,
  },

  //数量 减
  MinusPrice() {
    let _this = this;
    if (_this.data.num >1 ) {
      _this.setData({
        num: _this.data.num-1,
      })
    } else {
      wx.showToast({
        title: '购买数量小于1!',
        icon: 'none'
      })
    }
    _this.calculate();
  },

  //数量 加
  addPrice() {
    let _this = this;
    if (_this.data.num < _this.data.inventory) {
      _this.setData({
        num: _this.data.num+1,
      })
    } else {
      wx.showToast({
        title: '购买数量已大于库存!',
        icon: 'none'
      })
    }
    _this.calculate();
  },

  //input onblur事件
  calcNum(e) {
    let _this = this;
    let val = parseInt(e.detail.value);
    if (val > _this.data.inventory) {
      _this.setData({
        num: _this.data.inventory
      })
    } else if (val > 1 && val <= _this.data.inventory) {
      _this.setData({
        num: val
      })
    }  else {
      _this.setData({
        num: 1
      })
    }
    _this.calculate();
  },

  //计算总金额
  calculate() {
    this.setData({
      amountPrice: (this.data.num * this.data.price).toFixed(2)
    })
  },

  //提交订单
  orderSubmit(e) {
    let _this = this;
      if (_this.data.payStatus) {
        _this.setData({
          payStatus: false
        })
        let skuStr = "", imageId = "";
        _this.data.skuStr.forEach((res) => {
          skuStr += res.skuName
        })
        let goodsArr = [{
          amount: _this.data.num,
          goodsCode: _this.data.goodsCode,
          skuCode: _this.data.skuCode,
          skuGroupStr: skuStr,
          imageId: _this.data.imageId,
          activityId: _this.data.activityId,
          goodsTitle: _this.data.name,
          priceStr: _this.data.price,
          goodsImgUrl: _this.data.goodsImgUrl,
          form_id: e.detail.formId,
          shareUserId: app.globalData.userId
        }]
        if (_this.data.addressInfo) {
          const data = {
            takeAddress: JSON.stringify(_this.data.addressInfo),
            token: app.globalData.token,
            orderGoods: JSON.stringify(goodsArr),
          }
          // console.log(goodsArr);
          app.postRequest(app.globalData.api.bookOrders, data).then((res) => {
            if (res.data.code === "200" && res.data.success) {
              let goodList = [{
                goodsImgUrl: _this.data.goodsImgUrl,
                name: _this.data.name,
                sellerName: _this.data.sellerName,
                skuStr: _this.data.skuStr,
                num: _this.data.num,
              }]
              let obj = JSON.stringify({
                userName: _this.data.userName,
                userPhone: _this.data.userPhone,
                addressName: _this.data.addressName,
                orderNo: res.data.data,
                price: _this.data.amountPrice,
                goodList: goodList
              })
              // _this.setData({
              //   payStatus: true
              // })
              wx.navigateTo({
                url: '../payOrder/payOrder?obj=' + obj,
              })
            } else {
              _this.setData({
                payStatus: true
              })
              wx.showToast({
                title: res.data.message,
                icon: 'none'
              })
            }
          })
        } else {
          wx.showToast({
            title: '请先选择地址',
            icon: 'none'
          })
        }
      }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // let _this = this;
    //注册组件
    new AddressPanel()
    let _this = this;
    if (app.globalData.goods) {
      let goods = app.globalData.goods;
      _this.setData({
        name: goods.goodsTitle,
        sellerName: goods.sellerName,
        skuCode: goods.skuCode,
        skuStr: goods.skuStr,
        price: goods.price,
        num: goods.num,
        inventory: goods.inventory,
        amountPrice: (goods.num * goods.price).toFixed(2),
        goodsImgUrl: goods.img[0],
        goodsCode: goods.goodsCode,
        activityId: goods.activityId,
        imageId: goods.imageId
      })
    }
    if (_this.data.addressId) {
      _this.queryAddressById();
    } else {
      //查询默认地址
      _this.queryDefaultAddress();
    }
  },
}))