// pages/goods/goodsList.js
import {AddressPanel} from '../../../component/address/address'
const app = getApp();
Page(Object.assign({}, AddressPanel, {
  /**
   * 页面的初始数据
   */
  data: {
    payStatus: true,
    goodsDetialList: [],
    totalNum: 0,
    totalPrice: 0,
    addressInfo: null,
  },

  //提交订单
  orderSubmit(e) {
    let _this = this;
      if (_this.data.payStatus) {
        _this.setData({
          payStatus: false
        })
        let result = [], child = {};
        _this.data.goodsDetialList.forEach((item) => {
          item.children.forEach((son) => {
            child = {
              amount: son.buyNum,
              goodsCode: son.goodsCode,
              skuCode: son.skuCode,
              activityId: son.activityId,
              shopCartBizId: son.shopCartBizId,
              shareUserId: son.shareUserId
            };
            result.push(child);
          })
        })
        if (_this.data.addressInfo) {
          const data = {
            takeAddress: JSON.stringify(_this.data.addressInfo),
            token: app.globalData.token,
            orderGoods: JSON.stringify(result),
          }
          app.postRequest(app.globalData.api.bookOrders, data).then((res) => {
            if (res.data.code === "200" && res.data.success) {
              let goodList = [];
              _this.data.goodsDetialList.forEach((item) => {
                item.children.forEach((son) => {
                  let skuStr = [];
                  son.des.forEach((sku)=>{
                    skuStr.push({
                      skuName: sku
                    })
                  });
                  goodList.push({
                    goodsImgUrl: son.imageUrl,
                    name: son.title,
                    skuStr: skuStr,
                    num: son.buyNum
                  })
                })
              })

              let obj = JSON.stringify({
                userName: _this.data.userName,
                userPhone: _this.data.userPhone,
                addressName: _this.data.addressName,
                orderNo: res.data.data,
                price: _this.data.totalPrice,
                goodList: goodList
              })
              wx.navigateTo({
                url: '../payOrder/payOrder?obj=' + obj,
              })
            } else {
              _this.setData({
                payStatus: true
              })
              wx.showToast({
                title: res.data.message,
                icon: 'none'
              })
            }
          })
        } else {
          wx.showToast({
            title: '请先选择地址',    
            icon: 'none'
          })
        }
      }
  },

  //获取商品总数
  getGoodsNum() {
    let totalNum = 0;
    if (this.data.goodsDetialList) {
      this.data.goodsDetialList.forEach((item,index) => {
        item.children.forEach((good) => {
          totalNum += parseInt(good.buyNum);
        })
      })
    }
    this.setData({
      totalNum: totalNum
    })
  },

  //获取商品总价格
  getGoodsPrice() {
    let totalPrice = 0;
    if (this.data.goodsDetialList) {
      this.data.goodsDetialList.forEach((item, index) => {
        item.children.forEach((good, index) => {
          totalPrice += good.price * good.buyNum;
        })
      })
    }
    this.setData({
      totalPrice: totalPrice.toFixed(2)
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // this.getOrderList();
    this.setData({
      goodsDetialList: JSON.parse(options.result)
    })
    this.getGoodsNum();
    this.getGoodsPrice();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    //注册组件
    new AddressPanel()
    let _this = this;
    if (_this.data.addressId) {
      _this.queryAddressById();
    } else {

      //查询默认地址
      _this.queryDefaultAddress();
    }
  },

  /**
  * 生命周期函数--监听页面卸载
  */
  onUnload: function () {
    
  },

}))