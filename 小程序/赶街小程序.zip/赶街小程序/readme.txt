﻿页面结构：
page:
	areaCode:				地区切换
	goods:商品模块(首页)
		goodsList:    		商品列表
		goodsDetail:  		商品详情
		confirmOrder: 		确认订单
		payOrder:	  		支付
		addressList:  		地址列表
		addressAddOrUpdata: 地址新增或修改
		payOrderResult:     支付结果
	personal:个人中心模块
		personalCenter:		个人中心
		myOrderList:		我的订单列表
		myOrderDetail:		订单详情
		refund:				申请退款
		refundDetail:		退款详情

11111

