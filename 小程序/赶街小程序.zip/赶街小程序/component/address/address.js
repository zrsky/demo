const app = getApp();
let _comData = {
  '__adpanel__.addressId': '',
  '__adpanel__.userName': '',
  '__adpanel__.userPhone': '',
  '__adpanel__.addressName': '',
  '__adpanel__.addressStatus': false,
};
let _comEvent = {
  jumpAddressList: function() {
    wx.navigateTo({
      url: '/pages/goods/addressList/addressList'
    })
  },
};
let _comMethod = {
  //查询默认收货地址
  queryDefaultAddress: function() {
    let _this = this;
    const data = {
      token: app.globalData.token
    }
    app.postRequest(app.globalData.api.queryDefaultAddress, data).then((res) => {
      if (res.data.code === "200" && res.data.success && res.data.data !== null) {
        let item = res.data.data;
        _this.setData({
          '__adpanel__.userName': item.name,
          '__adpanel__.userPhone': item.telephone,
          '__adpanel__.addressName': item.provinceName + item.cityName + item.countyName + item.address,
          'addressInfo': item,
        })
      } else {
        _this.setData({
          '__adpanel__.addressStatus': true,
          'addressInfo': null,
        })
      }
    })
  },

  //根据地址id查询收货地址
  queryAddressById: function() {
    let _this = this;
    const data = {
      token: app.globalData.token,
      addressId: _this.data.addressId
    }
    app.postRequest(app.globalData.api.queryAddressById, data).then((res) => {
      if (res.data.code === "200" && res.data.success && res.data.data !== null) {
        let item = res.data.data;
        _this.setData({
          '__adpanel__.userName': item.name,
          '__adpanel__.userPhone': item.telephone,
          '__adpanel__.addressName': item.provinceName + item.cityName + item.countyName + item.address,
          '__adpanel__.addressStatus': false,
          'addressInfo': item,
        })
      } else {
        wx.showToast({
          title: '选择地址失败',
          icon: 'none'
        })
      }
    })
  },
}

//组件类
function AddressPanel() {
  let pages = getCurrentPages()
  let curPage = pages[pages.length - 1]
  //组件中调用页面
  this._page = curPage
  Object.assign(curPage, _comEvent, _comMethod)
  curPage.setData({_comData})

  curPage.addressPanel = this
  return this
}

export {
  AddressPanel
}