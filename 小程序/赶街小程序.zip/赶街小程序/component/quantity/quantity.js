const app = getApp();

let _comEvent= {
   //购物车加减
  cartDecrease(e) {
    let parentIndex = e.target.dataset.parentindex;
    let sonIndex = e.target.dataset.sonindex;
    let cartData = this.data.cartData;
    if (cartData[parentIndex].children[sonIndex].buyNum <= 1) {
      let text = '商品数量只剩1了,不能再减了';
      this.showToast(text);
      return;
    }
    let quantity = cartData[parentIndex].children[sonIndex].buyNum - 1;
    this.data.cartData[parentIndex].children[sonIndex].buyNum = quantity;
    this.setData({
      cartData: this.data.cartData
    })
    this.updateTotalPrice();
  },
  cartAdd(e) {
    let parentIndex = e.target.dataset.parentindex;
    let sonIndex = e.target.dataset.sonindex;
    let cartData = this.data.cartData;
    let quantity = parseInt(cartData[parentIndex].children[sonIndex].buyNum) + 1;
    this.checkInventoryQuantity(quantity, parentIndex, sonIndex);
    this.updateTotalPrice();
  },
  inputCartNum(e) {
    if (!/^\d+$/.test(e.detail.value)) {
      wx.showToast({
        title: '请输入数字',
        icon: 'none',
        duration: 1000
      })
      this.setData({
        cartData: this.data.cartData
      })
      return;
    }
    let parentIndex = e.target.dataset.parentindex;
    let sonIndex = e.target.dataset.sonindex;
    let cartData = this.data.cartData;
    if (e.detail.value == cartData[parentIndex].children[sonIndex].buyNum) {
      return;
    }
    if (e.detail.value == '' || e.detail.value <= 0) {
      this.setData({
        cartData: cartData
      });
      let text = '购买数量必须大于0';
      this.showToast(text);
      return;
    }

    let quantity = e.detail.value;
    this.checkInventoryQuantity(quantity, parentIndex, sonIndex);
    this.updateTotalPrice();
  },
  checkInventoryQuantity(quantity,parentIndex,sonIndex) {
    let inventory = this.data.cartData[parentIndex].children[sonIndex].inventory;
    if(quantity > inventory) {
      wx.showToast({
        title: '商品库存不足',
        icon: 'none',
        duration: 1000
      })
    }else{
      this.data.cartData[parentIndex].children[sonIndex].buyNum = quantity;
    }
    this.setData({
      cartData: this.data.cartData
    })
  },
}

//组件类
function QuantityPanel() {
  let pages = getCurrentPages()
  let curPage = pages[pages.length - 1]
  //组件中调用页面
  this._page = curPage
  Object.assign(curPage, _comEvent)
  // curPage.setData(_comData)

  curPage.quantityPanel = this
  return this
}

export {
  QuantityPanel
}